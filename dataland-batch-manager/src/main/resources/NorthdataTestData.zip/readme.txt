NORTH DATA EXPORT
 
Edition: Testdaten M (Firmendaten Basis)
Land: Deutschland
Sprache: Deutsch
Format: CSV
Abgeschlossen am: 02.04.2024
 
FIRMENSTATISTIK
Aktiv: 11.746
Liquidation: 838
Terminiert: 14.366
GESAMT: 26.950